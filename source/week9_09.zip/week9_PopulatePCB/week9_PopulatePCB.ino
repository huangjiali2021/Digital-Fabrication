const int ledPin = D0;     // the number of the LED pin
 
void setup() {
  // initialize the LED pin as an output:
  pinMode(ledPin, OUTPUT);
}
 
void loop() {
 

// turn LED off:
digitalWrite(ledPin, HIGH);
delay(1000);
// turn LED on:
digitalWrite(ledPin, LOW);
delay(1000);
}