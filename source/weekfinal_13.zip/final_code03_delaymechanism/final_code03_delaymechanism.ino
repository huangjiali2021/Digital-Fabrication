// 定义Pin口
const int pins[] = {A0, A1, A2, A3};  // 存储Pin口数组
const int numPins = sizeof(pins) / sizeof(pins[0]);  // Pin口数量

void setup() {
  // 初始化串口通讯
  Serial.begin(9600);
}

void loop() {
  int magnetCount = 0;

  // 循环读取所有Pin口的模拟值，计算磁铁数量
  for (int i = 0; i < numPins; i++) {
    if (analogRead(pins[i]) > 2500) {
      magnetCount++;
    }
  }

  // 根据磁铁的数量打印消息并设置延时
  if (magnetCount > 0) {
    Serial.print("有");
    Serial.print(magnetCount);
    Serial.print("个磁铁");
    Serial.println();

    // 延时的计算：每多一个磁铁，延时增加1秒
    delay((magnetCount-1) * 1000);  // 1秒 × 磁铁数量
  }

  // 等待一段时间后再进行下一次检测
  delay(500);
}
