void setup() {
  pinMode(10, OUTPUT);  // 设置 D10 引脚为输出
  Serial.begin(115200);  // 初始化串口通信
}

void loop() {
  if (Serial.available() > 0) {
    char data = Serial.read();  // 读取数据
    if (data == '1') {
      digitalWrite(10, HIGH);  // 点亮 LED
    } else if (data == '0') {
      digitalWrite(10, LOW);  // 熄灭 LED
    }
  }
}
