#define HE A0
#define ADDR1 D3
#define ADDR2 D2
#define ADDR3 D1

int thresh = 2500;

void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("3x hall effect sensor example online");
  pinMode(ADDR1, OUTPUT);
  pinMode(ADDR2, OUTPUT);
  pinMode(ADDR3, OUTPUT);
}

void loop() {
  int he0 = getReadingAtAddress(0, 0, 0);
  int he1 = getReadingAtAddress(0, 0, 1);
  int he2 = getReadingAtAddress(0, 1, 0);
  int he3 = getReadingAtAddress(0, 1, 1);

  int b0 = (he0 > thresh) ? 1 : 0;
  int b1 = (he1 > thresh) ? 1 : 0;
  int b2 = (he2 > thresh) ? 1 : 0;
  int b3 = (he3 > thresh) ? 1 : 0;

  Serial.print(b0);
  Serial.print(b1);
  Serial.print(b2);
  Serial.println(b3);

  /* 
  Serial.print("he0:");
  Serial.print(he0);
  Serial.print(",");
  Serial.print("he1:");
  Serial.print(he1);
  Serial.print(",");
  Serial.print("he2:");
  Serial.print(he2);
  Serial.print(",");
  Serial.print("he3:");
  Serial.println(he3);
  */

  delay(20);
}

int getReadingAtAddress(bool bit1, bool bit2, bool bit3) {
  digitalWrite(ADDR1, bit1);
  digitalWrite(ADDR2, bit2);
  digitalWrite(ADDR3, bit3);

  return analogRead(HE);
  // 0, 0, 0 -> A1
  // 0, 0, 1 -> A2
  // 0, 1, 0 -> A3
  // 0, 1, 1 -> A4
}

