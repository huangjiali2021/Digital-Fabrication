/*
  ESP-NOW 示例 - 两个 ESP32 开发板通过串口输入控制 LED
  修改于 2024-04-29 by Gemini
  基于 Krisjanis Rijnieks 的代码 (https://randomnerdtutorials.com/esp-now-esp32-arduino-ide/)
*/

#include <esp_now.h>
#include "WiFi.h"

#define LED_PIN 10 // 使用 D10 引脚，正如您所要求的

// 替换为另一个 ESP32 开发板的 MAC 地址
uint8_t receiverAddress[] = {0x64, 0xE8, 0x33, 0x84, 0x01, 0xE8};  // 示例 MAC 地址 - 请修改！

// 用于发送数据的结构体
typedef struct ControlMessage {
  char command; // '1' 代表开，'0' 代表关
} ControlMessage;

ControlMessage outgoingMessage;
ControlMessage incomingMessage;

esp_now_peer_info_t peerInfo;

// 数据发送完成后的回调函数
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.print("\r\n上次数据包发送状态:\t");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "发送成功" : "发送失败");
}

// 接收到数据后的回调函数
void OnDataRecv(const esp_now_recv_info_t *info, const uint8_t *incomingData, int len) {
  memcpy(&incomingMessage, incomingData, sizeof(incomingMessage));
  Serial.print("接收到的字节数: ");
  Serial.println(len);
  Serial.print("接收到的命令: ");
  Serial.println(incomingMessage.command);

  if (incomingMessage.command == '1') {
    digitalWrite(LED_PIN, HIGH);
  } else if (incomingMessage.command == '0') {
    digitalWrite(LED_PIN, LOW);
  }
  Serial.println();
}

void setup() {
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW 初始化失败");
    return;
  }

  Serial.print("设备 MAC 地址: ");
  Serial.println(WiFi.macAddress());

  // 注册发送和接收回调函数
  esp_now_register_send_cb(OnDataSent);
  esp_now_register_recv_cb(OnDataRecv);

  //  注册对等设备
  memcpy(peerInfo.peer_addr, receiverAddress, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;

  // 添加对等设备
  if (esp_now_add_peer(&peerInfo) != ESP_OK) {
    Serial.println("添加对等设备失败");
    return;
  }

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW); // 初始化时 LED 关闭
}

void loop() {
  if (Serial.available() > 0) {
    char command = Serial.read();
    if (command == '1' || command == '0') {
      outgoingMessage.command = command;
      esp_err_t result = esp_now_send(receiverAddress, (uint8_t *) &outgoingMessage, sizeof(outgoingMessage));

      if (result == ESP_OK) {
        Serial.println("发送命令: " + String(command));
        digitalWrite(LED_PIN, (command == '1' ? HIGH : LOW)); // 同时更新本地 LED 的状态
      } else {
        Serial.println("发送数据错误");
      }
    } else {
      Serial.println("无效输入。请输入 '1' 或 '0'。");
    }
  }
  delay(10);
}