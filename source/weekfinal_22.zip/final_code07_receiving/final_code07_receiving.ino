#include "Arduino.h"
#include "DFRobotDFPlayerMini.h"
#define FPSerial Serial1
DFRobotDFPlayerMini myDFPlayer;
void printDetail(uint8_t type, int value);


// 定义Pin口
#define HE A0
#define ADDR1 D3
#define ADDR2 D2
#define ADDR3 D1
int thresh = 2500;


const int ledPin = 8;     // LED连接到D8口
const int buttonPin = 9;  // 按钮连接到D9口
int buttonState = 0;      // 按钮的当前状态
int lastButtonState = 0;  // 上一次按钮的状态

// 用于LED非阻塞控制的变量
unsigned long ledOnMillis = 0; // 记录LED点亮时的时间
const long ledDuration = 400;  // LED点亮持续时间 (毫秒)
bool ledIsOn = false;          // 标记LED当前是否亮着

#include <esp_now.h>
#include "WiFi.h"

// Define the data structure to receive
typedef struct {
  bool buttonPressed;
} MyMessage;

MyMessage messageIn; // Incoming message

// Callback when data is received
void OnDataRecv(const esp_now_recv_info_t *info, const uint8_t *incomingData, int len) {
  memcpy(&messageIn, incomingData, sizeof(messageIn)); // Copy received data into messageIn

  Serial.print("Bytes received: ");
  Serial.println(len);

  // Check if the message indicates a button press
  if (messageIn.buttonPressed) {
    Serial.println("另一个板子按下了按钮！");
    int he0 = getReadingAtAddress(0,0,0);
    int he1 = getReadingAtAddress(0,0,1);
    int he2 = getReadingAtAddress(0,1,0);
    int he3 = getReadingAtAddress(0,1,1);

    const int pins[] = {he0, he1, he2, he3};  // 存储Pin口数组
    const int numPins = sizeof(pins) / sizeof(pins[0]);  // Pin口数量

    int magnetCount = 0;

    // 循环读取所有Pin口的模拟值，计算磁铁数量
    for (int i = 0; i < numPins; i++) {
      if (pins[i]> thresh) {
        magnetCount++;
      }
    }
    
    // 根据磁铁的数量打印消息并设置延时
    if (magnetCount > 1) {
      Serial.print("有");
      Serial.print(magnetCount);
      Serial.print("个磁铁");
      Serial.println();
      // 延时的计算：每多一个磁铁，延时增加1.5秒
      // 注意：这里的delay()仍然是阻塞的，如果希望也是非阻塞的，需要类似处理
      delay((magnetCount-1) * 1500);  // 秒 × 磁铁数量
      myDFPlayer.play(1);  //Play the first mp3
      
      // 非阻塞点亮LED
      digitalWrite(ledPin, HIGH);
      ledOnMillis = millis(); // 记录LED点亮的时刻
      ledIsOn = true;         // 标记LED正在亮着

    }else if(magnetCount == 1){
      Serial.print("有1个磁铁");
      Serial.println();
      myDFPlayer.play(1);  //Play the first mp3
      
      // 非阻塞点亮LED
      digitalWrite(ledPin, HIGH);
      ledOnMillis = millis(); // 记录LED点亮的时刻
      ledIsOn = true;         // 标记LED正在亮着
    }
  }

}


void setup()
{
  FPSerial.begin(9600, SERIAL_8N1, /*rx =*/D7, /*tx =*/D6);

  delay(3000);

  Serial.begin(115200);

  WiFi.mode(WIFI_STA);

  Serial.print("This Board MAC address: ");
  Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // Register receive callback
  esp_now_register_recv_cb(OnDataRecv);

  if (!myDFPlayer.begin(FPSerial, /*isACK = */true, /*doReset = */true)) {  //Use serial to communicate with mp3.
    Serial.println(F("Unable to begin:"));
    Serial.println(F("1.Please recheck the connection!"));
    Serial.println(F("2.Please insert the SD card!"));
    while(true){
      delay(0); // Code to compatible with ESP8266 watch dog.
    }
  }
  Serial.println(F("DFPlayer Mini online."));

  myDFPlayer.volume(30);  //Set volume value. From 0 to 30
  pinMode(ADDR1, OUTPUT);
  pinMode(ADDR2, OUTPUT);
  pinMode(ADDR3, OUTPUT);
  pinMode(buttonPin, INPUT);   // 设置按钮引脚为输入模式
  pinMode(ledPin, OUTPUT);     // 设置LED引脚为输出模式
  
  lastButtonState = digitalRead(buttonPin);
}



void loop() {
  // 处理本地按钮按下
  buttonState = digitalRead(buttonPin);  // 读取按钮的状态
  if (buttonState == HIGH && lastButtonState == LOW) { // 检测到按钮从未按下到按下的瞬间
    myDFPlayer.play(1);  // 播放音乐
    
    // 非阻塞点亮LED
    digitalWrite(ledPin, HIGH);
    ledOnMillis = millis(); // 记录LED点亮的时刻
    ledIsOn = true;         // 标记LED正在亮着
  }
  lastButtonState = buttonState;  // 更新按钮的上一个状态

  // 检查LED是否需要关闭
  if (ledIsOn && millis() - ledOnMillis >= ledDuration) {
    digitalWrite(ledPin, LOW); // 关闭LED
    ledIsOn = false;           // 标记LED已关闭
  }
}


int getReadingAtAddress(bool bit1, bool bit2, bool bit3){
  digitalWrite(ADDR1, bit1);
  digitalWrite(ADDR2, bit2);
  digitalWrite(ADDR3, bit3);
  return analogRead(HE);
}