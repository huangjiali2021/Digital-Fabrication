void setup() {
  pinMode(A0, INPUT);  // 设置 analog pin A0 引脚为输出
  Serial.begin(115200);  // 初始化串口通信

}

void loop() {
 float sensorValue = analogRead(A0);

 Serial.println(sensorValue);
 delay(100); 

}
