/*
  ESP-NOW Example - Sender Board (Multiple Receivers)
  Sends a message to multiple XIAO ESP32 boards when a button is pressed.
  Created 2024-05-27 by Gemini
*/

#include <esp_now.h>
#include "WiFi.h"

#define BTN_PIN D0 // Button connected to D0 and GND

// 定义所有接收板的 MAC 地址
const uint8_t receiverAddresses[][6] = {
  {0x64, 0xE8, 0x33, 0x84, 0x01, 0xE8}, // 64:E8:33:84:01:E8 Receiver Board A (第一个接收板)
  {0x64, 0xE8, 0x33, 0x87, 0x51, 0x44},  // 64:E8:33:87:51:44 Receiver Board B (第二个接收板) 虚拟地址，需要获取真正地址后修改
  {0x64, 0xE8, 0x33, 0x84, 0x60, 0x34},//64:E8:33:84:60:34
  {0x64, 0xE8, 0x33, 0x85, 0x4F, 0x70} //64:E8:33:85:4F:70
};
// 计算接收板的数量
const int numReceivers = sizeof(receiverAddresses) / sizeof(receiverAddresses[0]);


// Define the data structure to send
typedef struct {
  bool buttonPressed;
} MyMessage;

MyMessage messageOut; // Outgoing message

esp_now_peer_info_t peerInfo;

bool lastBtnState = HIGH; // To track button state for edge detection (HIGH because of INPUT_PULLUP)
unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50; // Debounce delay in milliseconds

// Callback when data is sent
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.print("\r\nLast Packet Sent Status to ");
  // 打印出发送给哪个MAC地址的结果
  char macStr[18];
  sprintf(macStr, "%02X:%02X:%02X:%02X:%02X:%02X",
          mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);
  Serial.print(macStr);
  Serial.print(":\t");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
}

void setup() {
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);

  Serial.print("This Board MAC address: ");
  Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // Register send callback
  esp_now_register_send_cb(OnDataSent);

  // Register all peers
  peerInfo.channel = 0;
  peerInfo.encrypt = false;

  for (int i = 0; i < numReceivers; i++) {
    memcpy(peerInfo.peer_addr, receiverAddresses[i], 6);
    if (esp_now_add_peer(&peerInfo) != ESP_OK) {
      Serial.print("Failed to add peer: ");
      char macStr[18];
      sprintf(macStr, "%02X:%02X:%02X:%02X:%02X:%02X",
              receiverAddresses[i][0], receiverAddresses[i][1], receiverAddresses[i][2],
              receiverAddresses[i][3], receiverAddresses[i][4], receiverAddresses[i][5]);
      Serial.println(macStr);
      return; // 如果有一个peer添加失败，可能需要停止或者处理错误
    }
    Serial.print("Successfully added peer: ");
    char macStr[18];
    sprintf(macStr, "%02X:%02X:%02X:%02X:%02X:%02X",
            receiverAddresses[i][0], receiverAddresses[i][1], receiverAddresses[i][2],
            receiverAddresses[i][3], receiverAddresses[i][4], receiverAddresses[i][5]);
    Serial.println(macStr);
  }

  pinMode(BTN_PIN, INPUT_PULLUP); // Button connected to D0 and GND, so use INPUT_PULLUP
}

void loop() {
  int reading = digitalRead(BTN_PIN);

  // If the button state has changed
  if (reading != lastBtnState) {
    // Reset the debouncing timer
    lastDebounceTime = millis();
  }

  if ((millis() - lastDebounceTime) > debounceDelay) {
    // If the button state has changed AND the debounce delay has passed
    if (reading != digitalRead(BTN_PIN)) { // Read again to confirm after debounce
      reading = digitalRead(BTN_PIN); // Update reading
    }

    if (reading == LOW && lastBtnState == HIGH) { // Button is pressed (LOW because of INPUT_PULLUP)
      Serial.println("Button pressed! Sending message to all receivers...");
      messageOut.buttonPressed = true; // Set message to indicate button press

      // 循环发送给每一个接收板
      for (int i = 0; i < numReceivers; i++) {
        esp_err_t result = esp_now_send(receiverAddresses[i], (uint8_t *) &messageOut, sizeof(messageOut));

        Serial.print("Attempted to send to ");
        char macStr[18];
        sprintf(macStr, "%02X:%02X:%02X:%02X:%02X:%02X",
                receiverAddresses[i][0], receiverAddresses[i][1], receiverAddresses[i][2],
                receiverAddresses[i][3], receiverAddresses[i][4], receiverAddresses[i][5]);
        Serial.print(macStr);
        Serial.print(" - Status: ");
        if (result == ESP_OK) {
          Serial.println("Success");
        } else {
          Serial.println("Error");
        }
      }
    }
  }

  lastBtnState = reading; // Save the current state for next loop iteration
}