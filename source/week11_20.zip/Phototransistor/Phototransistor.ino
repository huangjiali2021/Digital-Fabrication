// 定义光敏三极管连接的模拟引脚
const int phototransistorPin = A0; // 使用 A0 引脚读取模拟值

void setup() {
  Serial.begin(115200); // 初始化串口通信
  analogReadResolution(12); // 设置 ADC 分辨率为 12 位（0–4095）
}

void loop() {
  int sensorValue = analogRead(phototransistorPin); // 读取模拟值
  float voltage = sensorValue * (3.3 / 4095.0); // 将读取值转换为电压（0–3.3V）
  Serial.print("光强度值/Light intensity value: ");
  Serial.print(sensorValue);
  Serial.print("，电压/Voltage: ");
  Serial.println(voltage, 3); // 打印电压值，保留三位小数
  delay(500); // 延时 500 毫秒
}
