#define SERVO_PIN D1

void setup() {
  pinMode(SERVO_PIN, OUTPUT);
}

void loop() {
  for (int i = 0; i < 50; i++) {
    digitalWrite(SERVO_PIN, HIGH);
    delayMicroseconds(500);
    digitalWrite(SERVO_PIN, LOW);
    delay(20);
  }

  for (int i = 0; i < 50; i++) {
    digitalWrite(SERVO_PIN, HIGH);
    delayMicroseconds(2500);
    digitalWrite(SERVO_PIN, LOW);
    delay(20);
  }
}
