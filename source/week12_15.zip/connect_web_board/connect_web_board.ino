#include <WiFi.h>
#include <ESPAsyncWebServer.h>

const char* ssid = "Fablab";
const char* password = "Fabricationlab1";

// 创建一个 Web 服务器实例
AsyncWebServer server(80);

void setup() {
  // 启动串口调试
  Serial.begin(115200);
  
  // 连接到 Wi-Fi 网络
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("正在连接到 WiFi...");
  }
  Serial.println("WiFi 连接成功!");

  // 打印 ESP32C3 IP 地址
  Serial.print("IP 地址：");
  Serial.println(WiFi.localIP());

  // 设置 Web 服务器路由
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(200, "text/plain", "Hello, this is XIAO_ESP32C3!");
  });

  // 启动 Web 服务器
  server.begin();
}

void loop() {
  // Web 服务器不需要做其他操作
}

