#include <Servo.h>  // 引入舵机库

Servo myServo;  // 创建一个舵机对象

void setup() {
  myServo.attach(D1);  // 将舵机连接到 D1 引脚
}

void loop() {
  // 转动舵机从 0° 到 180° 
  for (int pos = 0; pos <= 180; pos++) {
    myServo.write(pos);  // 设置舵机的角度
    delay(15);  // 等待 15ms 让舵机完成转动
  }

  // 然后从 180° 转动回 0°
  for (int pos = 180; pos >= 0; pos--) {
    myServo.write(pos);  // 设置舵机的角度
    delay(15);  // 等待 15ms 让舵机完成转动
  }
}

